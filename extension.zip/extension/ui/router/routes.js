export const routes = {
  home: "home",
  tasks: "tasks",
  settings: "settings",
};
